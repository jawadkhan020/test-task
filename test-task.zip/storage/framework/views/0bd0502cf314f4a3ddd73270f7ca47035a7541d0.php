<h2>Welcome to  Car Management System</h2> <br><br>

<?php echo e($description); ?> <br><br>
<h2>Your Login Credintials Are </h2> <br>
<br>
<h2><b>Email: </b> <?php echo e($to); ?></h2> <br>
<h2> <b>Passeord: </b> <?php echo e($password); ?> </h2> <br>
Thanks
<p>Regards:  <strong>Test Task Care Managament System</strong></p><?php /**PATH E:\xampp\htdocs\personal\test-task\resources\views/admin/email/login_credentials.blade.php ENDPATH**/ ?>